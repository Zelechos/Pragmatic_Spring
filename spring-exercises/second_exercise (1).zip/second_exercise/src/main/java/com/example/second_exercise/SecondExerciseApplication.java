package com.example.second_exercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondExerciseApplication.class, args);
	}

}
