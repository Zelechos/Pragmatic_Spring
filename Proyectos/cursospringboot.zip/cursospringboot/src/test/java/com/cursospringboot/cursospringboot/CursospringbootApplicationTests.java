package com.cursospringboot.cursospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursospringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
